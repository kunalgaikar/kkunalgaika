NMake Makefiles
---------------

Generates NMake makefiles.
